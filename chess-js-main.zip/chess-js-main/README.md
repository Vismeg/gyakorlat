A JS keretrendszer előtti - lebutított JS backend végpontból lekérdezett tartalma - ugyanakkor kódból kreált verziója.
